# sokoban_player.py

from cmu_graphics import *
from sokoban_loader import *

runApp(600, 600, useHardcodedLevel=False)